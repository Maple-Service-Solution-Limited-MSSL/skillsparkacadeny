<section style="background-color: white;">
<div class="container" id="hanging-icons">
    <div class="row g-4 py-4 row-cols-1 row-cols-lg-3 ">
      <div class="col d-flex align-items-start">
        <div class="text-dark flex-shrink-0 me-3 my-2">
        <i class="fa-solid fa-desktop fa-xl" style="color: #198754;"></i>
        </div>
        <div>
          <h2>Online courses</h2>
          <p>Explore a variety of fresh topics</p>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <div class="text-dark flex-shrink-0 me-3 my-2">
             <i class="fa-solid fa-users fa-xl" style="color: #198754;"></i>
        </div>
        <div>
          <h2>Expert Instruction</h2>
          <p>Find the right instructor for you</p>
         
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <div class="text-dark flex-shrink-0 me-3 my-2">
             <i class="fa-solid fa-clock-rotate-left fa-xl" style="color: #198754;"></i>
        </div>
        <div>
          <h2>Lifetime access</h2>
          <p>Learn on your schedule</p>
        </div>
      </div>
    </div>
  </div>
</section>