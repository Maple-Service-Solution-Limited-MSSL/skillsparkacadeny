<?php
$routes = [
    '' => 'home.php',       
    'about' => 'about.php',
    'contact' => 'contact.php',
];